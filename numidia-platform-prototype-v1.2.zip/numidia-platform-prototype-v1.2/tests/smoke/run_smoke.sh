#!/bin/sh
set -e
# wait for services to be ready
sleep 30
# get token using direct access grant
TOKEN=$(curl -s -d "grant_type=password&client_id=$KEYCLOAK_CLIENT_ID&username=$KEYCLOAK_USERNAME&password=$KEYCLOAK_PASSWORD" -X POST "$KEYCLOAK_URL/realms/$KEYCLOAK_REALM/protocol/openid-connect/token" | jq -r '.access_token')
if [ -z "$TOKEN" ] || [ "$TOKEN" = "null" ]; then
  echo "Unable to obtain token" >&2
  exit 1
fi
# create citizen
curl -s -X POST -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
    --data '{"nin":"NIN1001","name":"Test User"}' "$API_CITIZENS/citizens" || true
# create high-risk declaration
curl -s -X POST -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
    --data '{"nin":"NIN1001","goods":"electronic components","value":120000,"origin_country":"KY"}' "$API_CUSTOMS/declarations" || true
# register vehicle
curl -s -X POST -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
    --data '{"nin":"NIN1001","license_plate":"AA-123-BB","model":"TestCar"}' "$API_TRANSPORT/vehicles" || true
# check health of services
curl -s "$API_CITIZENS/health"
curl -s "$API_CUSTOMS/health"
curl -s "$API_TRANSPORT/health"
echo "Smoke test completed"
