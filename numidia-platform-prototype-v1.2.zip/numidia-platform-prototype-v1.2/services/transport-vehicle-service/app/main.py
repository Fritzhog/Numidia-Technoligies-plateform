from fastapi import FastAPI
from pydantic import BaseModel
import os
import psycopg2
from kafka import KafkaProducer
import json

app = FastAPI()

producer = KafkaProducer(
    bootstrap_servers=os.environ['KAFKA_BOOTSTRAP_SERVERS'],
    value_serializer=lambda v: json.dumps(v).encode('utf-8'),
)

DB_CONN = {
    'host': os.environ['DB_HOST'],
    'user': os.environ['DB_USER'],
    'password': os.environ['DB_PASSWORD'],
    'dbname': os.environ['DB_NAME'],
}

def get_db():
    conn = psycopg2.connect(**DB_CONN)
    conn.autocommit = True
    return conn

class Vehicle(BaseModel):
    nin: str
    license_plate: str
    model: str

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/vehicles")
def register_vehicle(vehicle: Vehicle):
    with get_db() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "INSERT INTO vehicles (license_plate, nin, model) VALUES (%s,%s,%s) ON CONFLICT (license_plate) DO NOTHING",
                (vehicle.license_plate, vehicle.nin, vehicle.model),
            )
    producer.send(os.environ['KAFKA_TOPIC'], vehicle.dict())
    return {"message": "registered"}
